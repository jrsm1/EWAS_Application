https://www.lucidchart.com/documents/view/e9eaf4b4-44e4-4052-b6a0-1c8ec229d4d9/0
